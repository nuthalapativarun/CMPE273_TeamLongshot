package com.example.sanketh.attendance;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.AsyncTask;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.methods.HttpGet;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;

public class Login extends Activity {

    public static String sjsuid;
    public static String mac;

    TextView content;
    EditText login,pass;

    @Override
    public void onBackPressed() {

        finish();
        Intent intent = new Intent(Login.this, MainActivity.class);
        startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        content   =  (TextView)findViewById(R.id.content);
        login       =  (EditText)findViewById(R.id.sSJSUID);
        pass       =  (EditText)findViewById(R.id.sPassword);

        mac = BluetoothAdapter.getDefaultAdapter().getAddress();

        Button signIn=(Button)findViewById(R.id.bLogin);

        TextView SignUp =(TextView) findViewById(R.id.tvRegisterLink);
        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, Register.class);
                startActivity(intent);
                finish();
            }
        });

        signIn.setOnClickListener(new Button.OnClickListener(){
            public void onClick(View v) {

                switch (v.getId()) {

                    case R.id.bLogin:

                        if (!validate()) {
                            Toast.makeText(getBaseContext(), "Enter all the fields!", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(Login.this, Login.class);
                            startActivity(intent);
                            break;
                        }

                        String id = login.getText().toString();
                        sjsuid = id;
                        String password = pass.getText().toString();

                        ProgressDialog.show(Login.this, "",
                                "Loading. Please wait...", true);
                        new HttpAsyncTask().execute("http://54.191.181.24:3000/profile/" + id + "/" + password + "/" + mac);
                        break;
                }
            }

                public String GET(String url){
                InputStream iStream = null;
                String result = "";
                try {

                    HttpClient httpclient = new DefaultHttpClient();

                    HttpResponse httpRes = (HttpResponse) httpclient.execute(new HttpGet(url));

                    iStream = httpRes.getEntity().getContent();

                    if(iStream != null) {
                        result = convertInputStreamToString(iStream);
                    }
                    else
                        result = "Did not work!";

                } catch (Exception e) {
                    Log.d("InputStream", e.getLocalizedMessage());
                }

                return result;
            }

            private String convertInputStreamToString(InputStream iStream) throws IOException {
                BufferedReader buffReader = new BufferedReader( new InputStreamReader(iStream));
                String l = "";
                String result = "";
                while((l = buffReader.readLine()) != null)
                    result += l;

                iStream.close();
                return result;

            }

            class HttpAsyncTask extends AsyncTask<String, Void, String> {
                @Override
                protected String doInBackground(String... urls) {

                    return GET(urls[0]);
                }

                @Override
                protected void onPostExecute(String result) {

                   try {
                        JSONObject json= (JSONObject) new JSONTokener(result).nextValue();
                        String stat = json.getString("status");
                       if (stat.equalsIgnoreCase("true"))
                       {
                           Toast.makeText(getBaseContext(), "Login Successful", Toast.LENGTH_LONG).show();
                           Intent intent = new Intent(Login.this, Logged.class);
                           startActivity(intent);
                       }
                       else
                       {
                           Toast.makeText(getBaseContext(), "Login Failed. Please check your credentials or You are not on your registered device.", Toast.LENGTH_LONG).show();
                           Intent intent = new Intent(Login.this, Login.class);
                           startActivity(intent);
                       }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

        });
    }

    private boolean validate() {
        if (login.getText().toString().trim().equals(""))
            return false;
        else if (pass.getText().toString().trim().equals(""))
            return false;
        else
            return true;
    }
}