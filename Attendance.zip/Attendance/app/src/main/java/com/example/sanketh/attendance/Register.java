package com.example.sanketh.attendance;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Register extends AppCompatActivity implements View.OnClickListener
{

    TextView textView;
    EditText fName, lName, sjsuID, sPassword, macAddress;
    Button bRegister;

    @Override
    public void onBackPressed() {

        finish();
        Intent intent = new Intent(Register.this, MainActivity.class);
        startActivity(intent);
    }

    Student student;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

      Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textView = (TextView) findViewById(R.id.textView);
        fName = (EditText) findViewById(R.id.fName);
        lName = (EditText) findViewById(R.id.lName);
        sjsuID = (EditText) findViewById(R.id.sjsuID);
        sPassword = (EditText) findViewById(R.id.sPassword);
        macAddress = (EditText) findViewById(R.id.macAddress);
        bRegister = (Button) findViewById(R.id.bRegister);

        bRegister.setOnClickListener(this);

        EditText editText = (EditText)findViewById(R.id.macAddress);
        editText.setText(BluetoothAdapter.getDefaultAdapter().getAddress());

    }

    public static String POST(String url, Student student){
        InputStream inputStream = null;
        String result = "";
        try {

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);

            String json = "";

            JSONObject jsonObject = new JSONObject();
            jsonObject.accumulate("firstname", student.getFirstname());
            jsonObject.accumulate("lastname", student.getLastname());
            jsonObject.accumulate("id", student.getId());
            jsonObject.accumulate("password", student.getPassword());
            jsonObject.accumulate("mac", student.getMac());

            json = jsonObject.toString();

            StringEntity se = new StringEntity(json);

            httpPost.setEntity(se);

            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            HttpResponse httpResponse = httpclient.execute(httpPost);

            inputStream = httpResponse.getEntity().getContent();

            if(inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        return result;
    }

   public boolean isConnected(){
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }
    @Override
    public void onClick(View view) {

        switch(view.getId()){

            case R.id.bRegister:

                if(!validate()) {
                    Toast.makeText(getBaseContext(), "Enter all the fields!", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Register.this, Register.class);
                    startActivity(intent);
                    break;
                }
                new HttpAsyncTask().execute("http://54.191.181.24:3000/profile");
                break;
        }

    }

    private class HttpAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            student = new Student();
            student.setFirstname(fName.getText().toString());
            student.setLastname(lName.getText().toString());
            student.setId(sjsuID.getText().toString());
            student.setPassword(sPassword.getText().toString());
            student.setMac(macAddress.getText().toString());

            return POST(urls[0], student);
        }
        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getBaseContext(), "Registered Successfully", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Register.this, Login.class);
            startActivity(intent);
        }
    }

    private boolean validate(){
        if(fName.getText().toString().trim().equals(""))
            return false;
        else if(lName.getText().toString().trim().equals(""))
            return false;
        else if(sjsuID.getText().toString().trim().equals(""))
            return false;
        else if(sPassword.getText().toString().trim().equals(""))
            return false;
        else if(macAddress.getText().toString().trim().equals(""))
            return false;
        else
            return true;
    }
    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }
}