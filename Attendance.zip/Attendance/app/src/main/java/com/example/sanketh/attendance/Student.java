package com.example.sanketh.attendance;

/**
 * Created by Sanketh on 5/7/2016.
 */
public class Student {

    private String firstname;
    private String lastname;
    private String id;
    private String password;
    private String mac;
    private String here;


    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getHere() {
        return here;
    }

    public void setHere(String here) {
        this.here = here;
    }
}
